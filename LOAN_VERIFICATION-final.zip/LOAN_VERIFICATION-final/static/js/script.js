/* =============================================================================
   script.js - Loan Sphere front-end behaviour
   -----------------------------------------------------------------------------
   Small, dependency-free helpers for the two pages of this site:

     1. showLoader()     -> called when the verification form is submitted,
                             shows a full-screen spinner while the server runs
                             OCR + the BERT model, so the user knows something
                             is happening instead of staring at a frozen page.

     2. updateFileLabel() -> shows the chosen file's name next to the file
                              input once the user picks a document.

     3. syncAcceptedTypes() -> updates which file types the <input type=file>
                                will accept based on the selected document
                                type (bank statements are PDF-only in this
                                build, payslips also accept PNG/JPG scans).
============================================================================= */

function showLoader() {
    const overlay = document.getElementById("loader-overlay");
    if (overlay) {
        overlay.style.display = "flex";
    }
}

function updateFileLabel(inputEl) {
    const labelEl = document.getElementById("chosen-file-name");
    if (!labelEl) return;

    if (inputEl.files && inputEl.files.length > 0) {
        labelEl.textContent = "Selected: " + inputEl.files[0].name;
        labelEl.style.color = "var(--neon-blue-soft)";
    } else {
        labelEl.textContent = "No file selected yet.";
    }
}

function syncAcceptedTypes(selectEl) {
    const fileInput = document.getElementById("file-input");
    if (!fileInput) return;

    if (selectEl.value === "bank") {
        fileInput.setAttribute("accept", ".pdf");
    } else {
        fileInput.setAttribute("accept", ".pdf,.png,.jpg,.jpeg");
    }
}

// Auto-dismiss flash messages after a few seconds so they don't linger.
document.addEventListener("DOMContentLoaded", function () {
    const flashes = document.querySelectorAll(".flash");
    flashes.forEach(function (flashEl) {
        setTimeout(function () {
            flashEl.style.transition = "opacity 0.6s ease";
            flashEl.style.opacity = "0";
            setTimeout(function () { flashEl.remove(); }, 600);
        }, 5000);
    });

    // If the doctype dropdown exists, run the accept-type sync once on load
    // in case the browser restored a previous selection.
    const doctypeSelect = document.getElementById("doctype-select");
    if (doctypeSelect) {
        syncAcceptedTypes(doctypeSelect);
    }
});
